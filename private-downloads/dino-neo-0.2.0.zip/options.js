const form = document.getElementById("f"), ok = document.getElementById("ok");
chrome.storage.local.get({ mode: "notify" }, ({ mode }) => {
  form.elements.mode.value = mode;
});
form.addEventListener("change", () => {
  chrome.storage.local.set({ mode: form.elements.mode.value }, () => {
    ok.textContent = "Enregistré";
    setTimeout(() => (ok.textContent = ""), 1500);
  });
});
