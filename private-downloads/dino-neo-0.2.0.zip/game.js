const cv = document.getElementById("c"), ctx = cv.getContext("2d");
const W = 900, H = 300, GY = 240, DX = 70;
const ACCENT = "#FF6B35";
const TEAL = "#2EC4B6";   // boosters et pouvoirs (distinct de l'orange des dangers)
const PAL = { // [jour, nuit]
  bg: ["#F7F7F5", "#14161A"], ink: ["#2B2E34", "#E8E8E4"],
  near: ["#E9E9E4", "#1E2127"], far: ["#EFEFEA", "#191C21"],
};
const rnd = (a, b) => a + Math.random() * (b - a);
const mix = (a, b, t) => {
  const p = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16));
  const x = p(a), y = p(b);
  return "rgb(" + x.map((v, i) => Math.round(v + (y[i] - v) * t)).join() + ")";
};
const col = (k, n) => mix(PAL[k][0], PAL[k][1], n);

let best = 0;
try { best = +localStorage.getItem("dino-best") || 0; } catch {}

let ci = 0;
try { ci = +localStorage.getItem("dino-char") || 0; } catch {}

// ---------- Sons (synthétisés, aucun fichier) ----------
let muted = false, ac = null;
try { muted = localStorage.getItem("dino-mute") === "1"; } catch {}
function tone(f1, f2, dur, type, vol, delay = 0) {
  if (muted) return;
  try {
    ac = ac || new (window.AudioContext || window.webkitAudioContext)();
    if (ac.state === "suspended") ac.resume();
    const t = ac.currentTime + delay, o = ac.createOscillator(), g = ac.createGain();
    o.type = type; o.frequency.setValueAtTime(f1, t); o.frequency.exponentialRampToValueAtTime(f2, t + dur);
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(ac.destination); o.start(t); o.stop(t + dur);
  } catch {}
}
const sfx = {
  jump: () => tone(320, 640, 0.14, "square", 0.05),
  land: () => tone(140, 70, 0.07, "triangle", 0.08),
  point: () => { tone(880, 880, 0.06, "square", 0.035); tone(1320, 1320, 0.08, "square", 0.035, 0.07); },
  die: () => { tone(330, 55, 0.5, "sawtooth", 0.09); tone(165, 40, 0.5, "square", 0.05, 0.05); },
  tick: () => tone(700, 700, 0.04, "triangle", 0.06),
  unlock: () => [523, 659, 784, 1047].forEach((f, i) => tone(f, f, 0.16, "triangle", 0.08, i * 0.1)),
  online: () => { tone(500, 500, 0.08, "triangle", 0.06); tone(750, 750, 0.1, "triangle", 0.06, 0.09); },
  offline: () => { tone(500, 500, 0.08, "triangle", 0.06); tone(330, 330, 0.12, "triangle", 0.06, 0.09); },
};
function setMuted(m) {
  muted = m;
  try { localStorage.setItem("dino-mute", m ? "1" : "0"); } catch {}
  if (!m) sfx.tick();
}
Object.assign(sfx, {
  pick: () => [660, 880, 1100].forEach((f, i) => tone(f, f * 1.02, 0.09, "triangle", 0.07, i * 0.06)),
  pop: () => tone(900, 200, 0.18, "triangle", 0.09),
  smash: () => tone(260, 90, 0.08, "sawtooth", 0.04),
  boom: () => { tone(180, 40, 0.35, "sawtooth", 0.1); tone(90, 30, 0.35, "square", 0.06); },
  laser: () => tone(1800, 300, 0.2, "sawtooth", 0.06),
  freeze: () => { tone(1400, 900, 0.25, "sine", 0.06); tone(1900, 1200, 0.25, "sine", 0.04, 0.05); },
  power: () => { tone(300, 900, 0.25, "sawtooth", 0.06); tone(450, 1350, 0.25, "triangle", 0.06); },
  revive: () => [392, 523, 659, 784].forEach((f, i) => tone(f, f, 0.12, "triangle", 0.08, i * 0.07)),
  jump2: () => tone(520, 900, 0.12, "square", 0.045),
});

// ---------- Boosters (ramassables) : w = poids de tirage, dur = durée en images (60 = 1 s) ----------
const BOOSTS = {
  shield: { name: "Bouclier", w: 14 },
  revive: { name: "Seconde chance", w: 6 },
  mini:   { name: "Mini", w: 10, fx: "mini", dur: 480 },
  djump:  { name: "Double saut", w: 12, fx: "djump", dur: 480 },
  glide:  { name: "Plané", w: 10, fx: "glide", dur: 480 },
  jet:    { name: "Jetpack", w: 7, fx: "jet", dur: 240 },
  slow:   { name: "Ralenti", w: 14, fx: "slow", dur: 300 },
  x2:     { name: "Score ×2", w: 12, fx: "x2", dur: 600 },
  rush:   { name: "Ruée", w: 6, fx: "rush", dur: 180 },
  clear:  { name: "Nettoyage", w: 9 },
};
const POWER_DIST = 7000;   // distance parcourue pour recharger la jauge de pouvoir

// ---------- Réseau ----------
let origin = null;                       // page qui a échoué, renseignée par background.js
const banner = { text: "", t: 0, persist: false };
function say(text, t, persist) { banner.text = text; banner.t = t; banner.persist = !!persist; }
function goBack() {
  if (origin) location.href = origin;
  else { banner.t = 0; banner.persist = false; }
}
try {
  chrome.tabs.getCurrent(tab => {
    if (!tab) return;
    chrome.storage.session.get("origin:" + tab.id, r => { origin = r["origin:" + tab.id] || null; });
  });
} catch {}
const BACK_MSG = "Connexion rétablie · Entrée pour recharger la page";
addEventListener("offline", () => { sfx.offline(); say("Hors-ligne", 240); });
addEventListener("online", () => {
  sfx.online();
  if (origin) say(BACK_MSG, 1e9, true); else say("Connexion rétablie", 300);
});
// Wi-Fi sans internet : l'événement « online » ne suffit pas, on vérifie activement.
setInterval(async () => {
  if (!origin || banner.persist) return;
  try {
    await fetch("https://cp.cloudflare.com/generate_204", { mode: "no-cors", cache: "no-store", signal: AbortSignal.timeout(4000) });
    sfx.online(); say(BACK_MSG, 1e9, true);
  } catch {}
}, 5000);

const s = {};
function reset() {
  Object.assign(s, {
    state: "idle", t: 0, score: 0, speed: 6, dist: 0, gap: 400, shake: 0, flash: 0,
    dy: 0, vy: 0, duck: false, air: false, holdJump: false,
    obs: [], dust: [], deadAt: 0, toast: null, hundred: 0,
    fx: {}, fxMax: {}, shield: false, revive: false, inv: 0, jumps: 0, leap: false, jetOn: false,
    gauge: 0, ts: 1, picks: [], waves: [], beams: [], nextBoost: 220,
    clouds: Array.from({ length: 4 }, () => ({ x: rnd(0, W), y: rnd(30, 110), w: rnd(50, 90) })),
    stars: Array.from({ length: 40 }, () => ({ x: rnd(0, W), y: rnd(10, 150), r: rnd(0.6, 1.6), p: rnd(0, 6) })),
  });
}
reset();

function fit() {
  const dpr = window.devicePixelRatio || 1, w = Math.min(innerWidth, 1000), k = w / W;
  cv.style.width = w + "px"; cv.style.height = H * k + "px";
  cv.width = W * k * dpr; cv.height = H * k * dpr;
  ctx.setTransform(k * dpr, 0, 0, k * dpr, 0, 0);
}
addEventListener("resize", fit); fit();

// ---------- Entrées ----------
function jump() {
  if (s.state === "idle") s.state = "run";
  else if (s.state === "dead") {
    if (performance.now() - s.deadAt > 350) { reset(); s.state = "run"; } else return;
  }
  if (s.fx.jet > 0) return;
  const vj = s.fx.lunar > 0 ? -9.5 : -13.5;
  if (!s.air) { s.vy = vj; s.air = true; s.holdJump = true; s.jumps = 1; sfx.jump(); }
  else if (s.jumps < (s.fx.multi > 0 ? 3 : s.fx.djump > 0 ? 2 : 1)) {   // sauts multiples
    s.vy = vj; s.holdJump = true; s.jumps++; sfx.jump2();
    for (let i = 0; i < 5; i++) s.dust.push({ x: DX + 20, y: GY - s.dy, vx: rnd(-2, 2), vy: rnd(0, 1.5), l: 0.8, c: TEAL, r: 3 });
  }
}
addEventListener("keydown", e => {
  if (e.code === "KeyM") setMuted(!muted);
  if (["ShiftLeft", "ShiftRight", "KeyX"].includes(e.code) && !e.repeat) usePower();
  if (e.code === "Enter" && banner.persist) goBack();
  if (s.state !== "run" && ["ArrowLeft", "KeyA"].includes(e.code)) setChar(-1);
  if (s.state !== "run" && ["ArrowRight", "KeyD"].includes(e.code)) setChar(1);
  if (["Space", "ArrowUp", "KeyW"].includes(e.code)) { e.preventDefault(); if (!e.repeat) jump(); }
  if (e.code === "ArrowDown" || e.code === "KeyS") { e.preventDefault(); s.duck = true; }
});
addEventListener("keyup", e => {
  if (["Space", "ArrowUp", "KeyW"].includes(e.code)) s.holdJump = false;
  if (e.code === "ArrowDown" || e.code === "KeyS") s.duck = false;
});
cv.addEventListener("pointerdown", e => {
  e.preventDefault();
  const r = cv.getBoundingClientRect(), x = (e.clientX - r.left) / r.width * W, y = (e.clientY - r.top) / r.height * H;
  if (banner.persist && y > 56 && y < 92 && Math.abs(x - W / 2) < 220) { goBack(); return; }
  if (s.state === "run" && x > W - 80 && y > H - 64) { usePower(); return; }
  if (s.state !== "run") {
    if (y > 172 && y < 225) { setChar(x < W / 2 ? -1 : 1); return; }
    if (x > W - 64 && y > 72 && y < 106) { setMuted(!muted); return; }
  }
  jump();
});
cv.addEventListener("pointerup", () => { s.holdJump = false; });

// ---------- Logique ----------
function hitbox() {
  const m = s.fx.mini > 0 ? 0.62 : 1, cx = DX + 20;   // « Mini » rétrécit aussi la hitbox
  return s.duck && !s.air
    ? { x: cx - 16 * m, y: GY - s.dy - 28 * m, w: 42 * m, h: 26 * m }
    : { x: cx - 14 * m, y: GY - s.dy - 46 * m, w: 32 * m, h: 44 * m };
}
function spawn() {
  const r = Math.random(), bird = s.score > 300 && r < 0.3;
  let o;
  if (bird) {
    const mid = Math.random() < 0.5;
    o = { type: "bird", w: 44, h: 26, y: GY - (mid ? 62 : 32) };
  } else if (r < 0.65) o = { type: "rock", w: rnd(28, 40), h: rnd(30, 42), y: 0 };
  else o = { type: "crystal", w: 50, h: 46, y: 0 };
  o.x = W + 20; if (o.type !== "bird") o.y = GY - o.h;
  s.obs.push(o);
  s.gap = rnd(280, 480) + s.speed * 22;
}
function die() {
  s.state = "dead"; s.shake = 14; s.flash = 1; s.deadAt = performance.now(); sfx.die();
  if (s.score > best) {
    best = Math.floor(s.score);
    try { localStorage.setItem("dino-best", best); } catch {}
  }
}
// ---------- Effets, boosters, pouvoirs ----------
function burst(o, c) {
  for (let i = 0; i < 10; i++) s.dust.push({ x: o.x + o.w / 2, y: o.y + o.h / 2, vx: rnd(-3, 3), vy: rnd(-4, 1), l: 1, c: c || null, r: rnd(2, 4) });
  sfx.smash();
}
function wave(x, y, max, full) { s.waves.push({ x, y, r: 10, max, full }); }
function setFx(key, dur) { s.fx[key] = dur; s.fxMax[key] = dur; }
function spawnPick(type) {
  if (!type) {
    const pool = Object.keys(BOOSTS).filter(t => !(t === "shield" && s.shield) && !(t === "revive" && s.revive));
    let r = Math.random() * pool.reduce((a, t) => a + BOOSTS[t].w, 0);
    type = pool.find(t => (r -= BOOSTS[t].w) < 0) || pool[0];
  }
  s.picks.push({ type, x: W + 30, y: Math.random() < 0.5 ? GY - 34 : GY - 105, ph: rnd(0, 6) });
}
function clearAll() {
  s.obs.forEach(o => { if (!o.dead) { o.dead = true; burst(o, TEAL); } });
  wave(DX + 20, GY - s.dy - 30, 700, true); s.shake = 8; sfx.boom();
}
function grab(type) {
  const b = BOOSTS[type];
  if (type === "shield") s.shield = true;
  else if (type === "revive") s.revive = true;
  else if (type === "clear") clearAll();
  else setFx(b.fx, b.dur);
  s.toast = { text: b.name, t: 110, c: TEAL }; sfx.pick();
}
// Pouvoirs de personnage
function roar() {            // Rex : onde de choc devant lui
  s.obs.forEach(o => { if (!o.dead && o.x < DX + 340 && o.x + o.w > DX) { o.dead = true; burst(o, TEAL); } });
  wave(DX + 40, GY - s.dy - 34, 340, false); s.shake = 10; sfx.boom();
}
function leapPower() {       // Chat : bond géant, invincible tant qu'il est en l'air
  s.vy = -16; s.air = true; s.jumps = Math.max(s.jumps, 1); s.leap = true; s.holdJump = true; sfx.jump();
}
function laser() {           // Robot : détruit les 2 prochains obstacles
  const y = GY - s.dy - 42;
  const t = s.obs.filter(o => !o.dead && o.x + o.w > DX + 30).sort((a, b) => a.x - b.x).slice(0, 2);
  if (!t.length) s.beams.push({ x1: DX + 44, y1: y, x2: W, y2: y, t: 14 });
  t.forEach(o => { s.beams.push({ x1: DX + 44, y1: y, x2: o.x + o.w / 2, y2: o.y + o.h / 2, t: 14 }); o.dead = true; burst(o, TEAL); });
  sfx.laser();
}
function blizzard() {        // Pingouin : les obstacles déjà à l'écran gèlent et deviennent inoffensifs
  s.obs.forEach(o => { o.frozen = true; });
  wave(DX + 20, GY - s.dy - 30, 520, true); sfx.freeze();
}
function usePower() {
  if (s.state !== "run" || s.gauge < 1) return;
  const p = cur().power;
  s.gauge = 0;
  if (p.fx) setFx(p.fx, p.dur);
  if (p.use) p.use();
  s.toast = { text: p.name + " !", t: 110, c: TEAL }; sfx.power();
}

function update(k) {
  s.t += k;
  if (s.toast && s.toast.t > 0) s.toast.t -= k;
  if (banner.t > 0 && !banner.persist) banner.t -= k;
  if (s.shake > 0) s.shake -= k;
  if (s.flash > 0) s.flash = Math.max(0, s.flash - 0.06 * k);
  if (s.state !== "run") return;

  const fx = s.fx;
  for (const key in fx) if (fx[key] > 0) fx[key] = Math.max(0, fx[key] - k);
  if (s.inv > 0) s.inv -= k;

  s.score += s.speed * k * 0.1 * (fx.x2 > 0 ? 2 : 1) * (fx.rush > 0 ? 3 : 1);
  CHARS.forEach(c => {
    if (c.at && !c.shown && best < c.at && s.score >= c.at) { c.shown = true; s.toast = { text: "Débloqué : " + c.name, t: 180 }; sfx.unlock(); }
  });
  const hnd = Math.floor(s.score / 100);
  if (hnd > s.hundred) { s.hundred = hnd; sfx.point(); }
  s.speed = Math.min(6 + s.score * 0.004, 14);
  s.gauge = Math.min(1, s.gauge + s.speed * k / POWER_DIST);

  // vitesse du décor : Ruée l'accélère, Ralenti la réduit (le personnage, lui, garde sa physique)
  s.ts += ((fx.rush > 0 ? 1.7 : fx.slow > 0 ? 0.6 : 1) - s.ts) * 0.08 * k;
  const sp = s.speed * s.ts;
  s.dist += sp * k;

  if (fx.jet > 0) {                                      // Jetpack : vol stabilisé en altitude
    s.air = true; s.vy = 0; s.jumps = 9; s.jetOn = true;
    s.dy += (130 - s.dy) * 0.1 * k;
    if (Math.random() < 0.7) s.dust.push({ x: DX + 4, y: GY - s.dy - 16, vx: rnd(-3, -1), vy: rnd(1, 3), l: 0.9, c: ACCENT, r: rnd(2, 4) });
  } else {
    if (s.jetOn) { s.jetOn = false; s.jumps = 1; s.inv = Math.max(s.inv, 60); }   // courte protection à l'atterrissage
    if (s.air) {
      const lunar = fx.lunar > 0, glide = fx.glide > 0 && s.holdJump && s.vy > 0;
      if (!s.holdJump && s.vy < -5 && !s.leap) s.vy = -5;                       // saut modulable
      s.vy += (s.duck ? (lunar ? 1.2 : 2) : (lunar ? 0.3 : 0.7)) * (glide ? 0.25 : 1) * k;
      if (glide && s.vy > 2.2) s.vy = 2.2;                                      // Plané
      s.dy -= s.vy * k;
      if (s.dy <= 0) {
        s.dy = 0; s.vy = 0; s.air = false; s.jumps = 0; s.leap = false; sfx.land();
        for (let i = 0; i < 6; i++) s.dust.push({ x: DX + 20, y: GY, vx: rnd(-2, 1), vy: rnd(-2, -0.5), l: 1 });
      }
    }
  }

  s.gap -= sp * k; if (s.gap <= 0) spawn();
  s.obs.forEach(o => o.x -= sp * k);
  // apparition d'un booster (jamais collé à un obstacle)
  if (s.score >= s.nextBoost && s.gap > 150 && s.obs.every(o => Math.abs(o.x - (W + 30)) > 150)) {
    spawnPick(); s.nextBoost = s.score + rnd(300, 500);
  }
  s.picks.forEach(p => {
    p.x -= sp * k;
    if (fx.magnet > 0 && p.x < W - 20) {                 // Poulpe : aimant à boosters
      p.x += (DX + 20 - p.x) * 0.07 * k; p.y += (GY - s.dy - 24 - p.y) * 0.07 * k;
    }
  });

  if (fx.flame > 0) {                                    // Dragon : souffle de feu
    const fy = GY - s.dy - 40;
    s.obs.forEach(o => {
      if (!o.dead && o.x < DX + 290 && o.x + o.w > DX + 44 && Math.abs(o.y + o.h / 2 - fy) < 45 + o.h / 2) { o.dead = true; burst(o, ACCENT); }
    });
    for (let i = 0; i < 2; i++) s.dust.push({ x: DX + 46, y: fy + rnd(-4, 4), vx: rnd(5, 9), vy: rnd(-0.6, 0.6), l: 0.7, c: ACCENT, r: rnd(2, 4.5) });
  }

  const hb = hitbox();
  s.picks = s.picks.filter(p => {
    const py = p.y + Math.sin(s.t / 12 + p.ph) * 4;
    if (hb.x < p.x + 15 && hb.x + hb.w > p.x - 15 && hb.y < py + 15 && hb.y + hb.h > py - 15) { grab(p.type); return false; }
    return p.x > -30;
  });
  for (const o of s.obs) {
    if (o.dead || o.frozen) continue;
    const m = 5;
    if (!(hb.x < o.x + o.w - m && hb.x + hb.w > o.x + m && hb.y < o.y + o.h - m && hb.y + hb.h > o.y + m)) continue;
    if (fx.rush > 0) { o.dead = true; burst(o); continue; }                                   // Ruée : tout explose
    if (fx.ghost > 0 || fx.jet > 0 || s.inv > 0 || s.leap) continue;                          // intangible / protégé
    if (fx.rebound > 0) { o.dead = true; burst(o, TEAL); s.vy = -12; s.air = true; s.jumps = 1; s.holdJump = true; sfx.jump(); continue; }
    if (s.shield) { s.shield = false; o.dead = true; burst(o, TEAL); s.inv = 45; sfx.pop(); continue; }
    if (s.revive) {
      s.revive = false; o.dead = true; burst(o, TEAL); s.inv = 120; s.flash = 0.7;
      s.toast = { text: "Seconde chance !", t: 120, c: TEAL }; sfx.revive(); continue;
    }
    die(); break;
  }
  s.obs = s.obs.filter(o => !o.dead && o.x + o.w > -20);

  s.dust.forEach(d => { d.x += d.vx * k; d.y += d.vy * k; d.vy += 0.15 * k; d.l -= 0.04 * k; });
  s.dust = s.dust.filter(d => d.l > 0);
  s.waves.forEach(w => { w.r += 14 * k; }); s.waves = s.waves.filter(w => w.r < w.max);
  s.beams.forEach(b => { b.t -= k; }); s.beams = s.beams.filter(b => b.t > 0);
  s.clouds.forEach(c => { c.x -= sp * 0.15 * k; if (c.x + c.w < 0) { c.x = W + 20; c.y = rnd(30, 110); } });
}

// ---------- Rendu ----------
function roundRect(x, y, w, h, r) { ctx.beginPath(); ctx.roundRect(x, y, w, h, r); ctx.fill(); }

function legs(ly, step) {
  roundRect(8, ly, 7, -ly - (step ? 5 : 0), 3);
  roundRect(24, ly, 7, -ly - (step ? 0 : 5), 3);
}
function drawRex(c) {
  legs(c.duck ? -10 : -14, c.step);
  if (c.duck) {
    roundRect(-4, -26, 46, 20, 10); roundRect(30, -32, 22, 16, 8);
    ctx.beginPath(); ctx.moveTo(-4, -20); ctx.lineTo(-18, -12); ctx.lineTo(-4, -10); ctx.fill();
    ctx.fillStyle = c.bg; ctx.beginPath(); ctx.arc(44, -25, 2.6, 0, 7); ctx.fill();
  } else {
    roundRect(0, -36, 34, 26, 12); roundRect(16, -52, 28, 22, 10);
    ctx.beginPath(); ctx.moveTo(2, -30); ctx.lineTo(-16, -14); ctx.lineTo(4, -18); ctx.fill();
    ctx.fillStyle = c.bg;
    if (c.blink) ctx.fillRect(34, -42, 6, 2); else { ctx.beginPath(); ctx.arc(37, -42, 3, 0, 7); ctx.fill(); }
  }
}
function drawCat(c) {
  ctx.strokeStyle = c.ink; ctx.lineWidth = 5; ctx.lineCap = "round";
  ctx.beginPath(); ctx.moveTo(3, -24); ctx.quadraticCurveTo(-16, -26, -10, -48); ctx.stroke();
  legs(-14, c.step);
  roundRect(0, -36, 34, 26, 12); roundRect(14, -52, 28, 22, 10);
  ctx.beginPath(); ctx.moveTo(17, -50); ctx.lineTo(21, -63); ctx.lineTo(28, -52);
  ctx.moveTo(30, -52); ctx.lineTo(36, -63); ctx.lineTo(40, -50); ctx.fill();
  ctx.fillStyle = c.bg;
  if (c.blink) ctx.fillRect(30, -42, 6, 2); else { ctx.beginPath(); ctx.arc(33, -42, 3, 0, 7); ctx.fill(); }
  ctx.fillStyle = ACCENT; ctx.beginPath(); ctx.arc(41, -37, 2, 0, 7); ctx.fill();
  ctx.strokeStyle = c.ink; ctx.lineWidth = 1.5; ctx.beginPath();
  ctx.moveTo(42, -38); ctx.lineTo(50, -41); ctx.moveTo(42, -35); ctx.lineTo(50, -34); ctx.stroke();
}
function drawBot(c) {
  legs(-12, c.step);
  roundRect(2, -40, 34, 30, 6); roundRect(30, -34, 10, 6, 3); roundRect(10, -58, 30, 20, 6);
  ctx.fillRect(23, -66, 2, 8);
  ctx.fillStyle = ACCENT; ctx.beginPath(); ctx.arc(24, -67, 3.2, 0, 7); ctx.fill();
  ctx.fillStyle = c.bg; ctx.fillRect(22, -52, 14, 8);
  ctx.fillStyle = ACCENT;
  if (c.blink) ctx.fillRect(27, -48, 6, 2); else { ctx.beginPath(); ctx.arc(29, -48, 2.6, 0, 7); ctx.fill(); }
}
function drawGhost(c) {
  ctx.translate(0, -4 - Math.sin(s.t / 8) * 2);
  ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, -34); ctx.arc(20, -34, 20, Math.PI, 0); ctx.lineTo(40, 0);
  for (let i = 0; i < 4; i++) ctx.quadraticCurveTo(40 - i * 10 - 5, (i + c.step) % 2 ? -8 : 8, 30 - i * 10, 0);
  ctx.fill();
  ctx.fillStyle = c.bg;
  if (c.blink) { ctx.fillRect(25, -39, 7, 2); ctx.fillRect(10, -39, 7, 2); }
  else { ctx.beginPath(); ctx.arc(29, -38, 3.5, 0, 7); ctx.arc(14, -38, 3.5, 0, 7); ctx.fill(); }
  roundRect(18, -28, 8, 6, 3);
}
function drawPingu(c) {
  ctx.beginPath(); ctx.ellipse(20, -26, 18, 26, 0, 0, 7); ctx.fill();
  ctx.fillStyle = c.bg; ctx.beginPath(); ctx.ellipse(24, -16, 10, 14, 0, 0, 7); ctx.fill();
  if (c.blink) ctx.fillRect(25, -41, 7, 2); else { ctx.beginPath(); ctx.arc(28, -40, 3.5, 0, 7); ctx.fill(); }
  ctx.fillStyle = ACCENT;
  ctx.beginPath(); ctx.moveTo(34, -38); ctx.lineTo(46, -34); ctx.lineTo(34, -30); ctx.fill();
  roundRect(8, -4 - (c.step ? 3 : 0), 11, 4, 2); roundRect(23, -4 - (c.step ? 0 : 3), 11, 4, 2);
}
function drawSlime(c) {
  const sy = c.air ? 1.12 : 1 + Math.sin(s.t / 5) * 0.04, sx = 1 / sy;
  ctx.translate(20, 0); ctx.scale(sx, sy); ctx.translate(-20, 0);
  roundRect(0, -36, 40, 36, [20, 20, 6, 6]);
  ctx.fillStyle = c.bg;
  if (c.blink) { ctx.fillRect(16, -23, 6, 2); ctx.fillRect(28, -23, 6, 2); }
  else { ctx.beginPath(); ctx.arc(19, -22, 3.5, 0, 7); ctx.arc(31, -22, 3.5, 0, 7); ctx.fill(); }
  ctx.globalAlpha = 0.35; ctx.beginPath(); ctx.ellipse(10, -27, 4, 2.5, -0.6, 0, 7); ctx.fill(); ctx.globalAlpha = 1;
}
function drawAstro(c) {
  legs(-14, c.step);
  roundRect(2, -38, 32, 28, 8); roundRect(-7, -36, 11, 22, 3);
  ctx.beginPath(); ctx.arc(26, -46, 15, 0, 7); ctx.fill();
  ctx.strokeStyle = c.bg; ctx.lineWidth = 2; ctx.stroke();
  ctx.fillStyle = c.bg; ctx.beginPath(); ctx.ellipse(31, -46, 10, 8, 0, 0, 7); ctx.fill();
  ctx.fillStyle = ACCENT; ctx.beginPath(); ctx.arc(35, -48, 2, 0, 7); ctx.fill();
}
function drawNinja(c) {
  legs(-14, c.step);
  roundRect(2, -38, 30, 28, 8);
  ctx.beginPath(); ctx.arc(24, -46, 12, 0, 7); ctx.fill();
  const len = 10 + s.speed * 2, w = Math.sin(s.t / 4) * 3;
  ctx.fillStyle = ACCENT;
  ctx.fillRect(14, -54, 22, 5);
  ctx.beginPath(); ctx.moveTo(14, -52); ctx.quadraticCurveTo(14 - len / 2, -56 + w, 14 - len, -50 + w * 1.5);
  ctx.lineTo(14 - len * 0.8, -46 + w); ctx.quadraticCurveTo(14 - len / 2, -50, 14, -49); ctx.fill();
  ctx.fillStyle = c.bg; roundRect(24, -45, 12, c.blink ? 1.5 : 4, 2);
}
function drawOcto(c) {
  ctx.beginPath(); ctx.ellipse(20, -36, 20, 20, 0, 0, 7); ctx.fill();
  ctx.strokeStyle = c.ink; ctx.lineWidth = 6; ctx.lineCap = "round";
  for (let i = 0; i < 4; i++) {
    const x = 6 + i * 10, f = (i + c.step) % 2 ? 7 : -7;
    ctx.beginPath(); ctx.moveTo(x, -24); ctx.quadraticCurveTo(x + f, -13, x + f / 2, -3); ctx.stroke();
  }
  ctx.fillStyle = c.bg;
  if (c.blink) { ctx.fillRect(10, -39, 8, 2); ctx.fillRect(24, -39, 8, 2); }
  else {
    ctx.beginPath(); ctx.arc(14, -38, 4.5, 0, 7); ctx.arc(28, -38, 4.5, 0, 7); ctx.fill();
    ctx.fillStyle = c.ink; ctx.beginPath(); ctx.arc(15.5, -38, 2, 0, 7); ctx.arc(29.5, -38, 2, 0, 7); ctx.fill();
  }
}
function drawDragon(c) {
  ctx.beginPath(); ctx.moveTo(10, -34); ctx.lineTo(-4, -62 + (c.step ? 8 : 0)); ctx.lineTo(28, -34); ctx.fill();
  drawRex({ ...c, duck: false });
  ctx.fillStyle = c.ink;
  [6, 16, 26].forEach(x => { ctx.beginPath(); ctx.moveTo(x - 4, -36); ctx.lineTo(x, -44); ctx.lineTo(x + 4, -36); ctx.fill(); });
  ctx.beginPath(); ctx.moveTo(20, -50); ctx.lineTo(23, -60); ctx.lineTo(27, -50);
  ctx.moveTo(32, -50); ctx.lineTo(36, -60); ctx.lineTo(39, -50); ctx.fill();
  if (s.state === "run" && s.t % 24 < 12) {
    ctx.fillStyle = ACCENT; ctx.globalAlpha = 0.8; ctx.beginPath(); ctx.arc(50, -42, 4, 0, 7); ctx.fill(); ctx.globalAlpha = 1;
  }
}
// `at` = meilleur score à atteindre pour débloquer le personnage (sans `at` : dispo dès le départ)
const CHARS = [
  { name: "Rex", draw: drawRex, power: { name: "Rugissement", use: roar } },
  { name: "Chat", draw: drawCat, squash: true, power: { name: "Saut félin", use: leapPower } },
  { name: "Robot", draw: drawBot, squash: true, power: { name: "Laser", use: laser } },
  { name: "Fantôme", draw: drawGhost, squash: true, power: { name: "Passe-muraille", fx: "ghost", dur: 180 } },
  { name: "Pingouin", draw: drawPingu, squash: true, power: { name: "Blizzard", use: blizzard } },
  { name: "Slime", draw: drawSlime, squash: true, at: 500, power: { name: "Rebond", fx: "rebound", dur: 240 } },
  { name: "Astronaute", draw: drawAstro, squash: true, at: 1000, power: { name: "Saut lunaire", fx: "lunar", dur: 300 } },
  { name: "Ninja", draw: drawNinja, squash: true, at: 1800, power: { name: "Triple saut", fx: "multi", dur: 360 } },
  { name: "Poulpe", draw: drawOcto, squash: true, at: 3000, power: { name: "Aimant à boosters", fx: "magnet", dur: 300, use: () => spawnPick() } },
  { name: "Dragon", draw: drawDragon, squash: true, at: 5000, power: { name: "Souffle de feu", fx: "flame", dur: 180 } },
];
const unlocked = c => !c.at || Math.max(best, s.score) >= c.at;
const cur = () => { const c = CHARS[ci]; return c && unlocked(c) ? c : CHARS[0]; };
function setChar(d) {
  let i = ci;
  do { i = (i + d + CHARS.length) % CHARS.length; } while (!unlocked(CHARS[i]) && i !== ci);
  ci = i;
  try { localStorage.setItem("dino-char", ci); } catch {}
  sfx.tick();
}

function drawDino(n) {
  const fx = s.fx, mini = fx.mini > 0;
  const c = {
    ink: col("ink", n), bg: col("bg", n), duck: s.duck && !s.air, blink: s.t % 220 < 6, air: s.air,
    step: s.state === "run" && !s.air ? Math.floor(s.t / 5) % 2 : 0,
  };
  const cx = DX + 22, cy = GY - s.dy - (mini ? 17 : 28), rx = mini ? 24 : 34, ry = mini ? 26 : 40;

  if (fx.flame > 0) {                                        // cône de flammes
    const fy = GY - s.dy - 40, L = 240 * (0.92 + 0.08 * Math.sin(s.t));
    ctx.save();
    ctx.fillStyle = ACCENT; ctx.globalAlpha = 0.5;
    ctx.beginPath(); ctx.moveTo(DX + 46, fy - 4); ctx.lineTo(DX + 46 + L, fy - 34); ctx.lineTo(DX + 46 + L, fy + 34); ctx.lineTo(DX + 46, fy + 4); ctx.fill();
    ctx.fillStyle = "#FFC857"; ctx.globalAlpha = 0.65;
    ctx.beginPath(); ctx.moveTo(DX + 46, fy - 3); ctx.lineTo(DX + 46 + L * 0.6, fy - 16); ctx.lineTo(DX + 46 + L * 0.6, fy + 16); ctx.lineTo(DX + 46, fy + 3); ctx.fill();
    ctx.restore();
  }
  if (fx.rush > 0) {                                         // traînées de vitesse
    ctx.save(); ctx.fillStyle = c.ink; ctx.globalAlpha = 0.3;
    for (let i = 0; i < 4; i++) ctx.fillRect(DX - 40 - i * 30 - (s.t * 14) % 30, cy - 22 + i * 12, 44, 3);
    ctx.restore();
  }

  ctx.save();
  ctx.globalAlpha = fx.ghost > 0 ? 0.42 : (s.inv > 0 && Math.floor(s.t / 4) % 2 ? 0.35 : 1);
  ctx.translate(DX, GY - s.dy);
  if (mini) { ctx.translate(20, 0); ctx.scale(0.62, 0.62); ctx.translate(-20, 0); }
  ctx.fillStyle = c.ink;
  if (c.duck && cur().squash) ctx.scale(1.12, 0.62);
  if (fx.jet > 0) { ctx.fillStyle = TEAL; roundRect(-10, -36, 8, 18, 3); ctx.fillStyle = c.ink; }
  cur().draw(c);
  ctx.restore();

  if (s.shield) {                                            // bulle de bouclier
    ctx.save(); ctx.fillStyle = TEAL; ctx.strokeStyle = TEAL; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.ellipse(cx, cy, rx, ry, 0, 0, 7); ctx.globalAlpha = 0.14; ctx.fill(); ctx.globalAlpha = 0.85; ctx.stroke(); ctx.restore();
  }
  if (fx.rebound > 0 || fx.lunar > 0 || fx.multi > 0) {      // halo des pouvoirs actifs
    ctx.save(); ctx.strokeStyle = TEAL; ctx.lineWidth = 2; ctx.globalAlpha = 0.5; ctx.setLineDash([5, 5]);
    ctx.beginPath(); ctx.ellipse(cx, cy, rx + 4, ry + 4, 0, 0, 7); ctx.stroke(); ctx.restore();
  }
  if (fx.magnet > 0) {
    ctx.save(); ctx.strokeStyle = TEAL; ctx.lineWidth = 2; ctx.globalAlpha = 0.3; ctx.setLineDash([4, 6]);
    ctx.beginPath(); ctx.arc(cx, cy, 70 + Math.sin(s.t / 8) * 6, 0, 7); ctx.stroke(); ctx.restore();
  }
  if (fx.glide > 0 && s.air) {                               // petite voilure
    ctx.save(); ctx.strokeStyle = TEAL; ctx.lineWidth = 3; ctx.lineCap = "round";
    ctx.beginPath(); ctx.arc(cx, cy - ry + 6, 20, Math.PI * 1.1, Math.PI * 1.9); ctx.stroke(); ctx.restore();
  }
}

function drawObs(o, n) {
  ctx.save(); ctx.translate(o.x, o.y);
  if (o.frozen) ctx.globalAlpha = 0.45;
  if (o.type === "rock") {
    ctx.fillStyle = col("ink", n);
    ctx.beginPath(); ctx.roundRect(0, o.h * 0.25, o.w, o.h * 0.75, [o.w * 0.5, o.w * 0.5, 4, 4]); ctx.fill();
  } else if (o.type === "crystal") {
    ctx.fillStyle = ACCENT;
    [[0, 30, 14], [14, 46, 16], [32, 34, 14]].forEach(([x, h, w]) => {
      ctx.beginPath(); ctx.moveTo(x, o.h); ctx.lineTo(x + w / 2, o.h - h); ctx.lineTo(x + w, o.h); ctx.fill();
    });
  } else {
    const up = Math.floor(s.t / 8) % 2;
    ctx.fillStyle = ACCENT;
    ctx.beginPath(); ctx.ellipse(22, 14, 18, 8, 0, 0, 7); ctx.fill();
    ctx.beginPath(); ctx.moveTo(10, 12); ctx.lineTo(24, up ? -2 : 28); ctx.lineTo(30, 12); ctx.fill();
    ctx.beginPath(); ctx.moveTo(4, 14); ctx.lineTo(-4, 12); ctx.lineTo(4, 10); ctx.fill();
  }
  if (o.frozen) { ctx.globalAlpha = 1; ctx.strokeStyle = "#8FD3F4"; ctx.lineWidth = 2; ctx.setLineDash([4, 3]); ctx.strokeRect(-3, -3, o.w + 6, o.h + 6); }
  ctx.restore();
}

// Icônes des boosters (dessinées dans un carré de 20 × 20 centré sur (x, y))
function drawIcon(type, x, y, sz, color) {
  ctx.save(); ctx.translate(x, y); ctx.scale(sz / 20, sz / 20);
  ctx.fillStyle = color; ctx.strokeStyle = color; ctx.lineWidth = 2.4; ctx.lineCap = "round"; ctx.lineJoin = "round";
  ctx.beginPath();
  switch (type) {
    case "shield":
      ctx.moveTo(0, -9); ctx.lineTo(8, -6); ctx.lineTo(7, 3); ctx.quadraticCurveTo(5, 8, 0, 10);
      ctx.quadraticCurveTo(-5, 8, -7, 3); ctx.lineTo(-8, -6); ctx.closePath(); ctx.fill(); break;
    case "revive":
      ctx.moveTo(0, 8); ctx.bezierCurveTo(-12, 0, -8, -9, 0, -3); ctx.bezierCurveTo(8, -9, 12, 0, 0, 8); ctx.fill(); break;
    case "mini":
      ctx.rect(-9, -9, 18, 18); ctx.stroke(); ctx.beginPath(); ctx.rect(-3, -3, 6, 6); ctx.fill(); break;
    case "djump":
      ctx.moveTo(-7, 0); ctx.lineTo(0, -7); ctx.lineTo(7, 0); ctx.moveTo(-7, 8); ctx.lineTo(0, 1); ctx.lineTo(7, 8); ctx.stroke(); break;
    case "glide":
      ctx.arc(0, -1, 9, Math.PI, 0); ctx.closePath(); ctx.fill();
      ctx.beginPath(); ctx.moveTo(-9, -1); ctx.lineTo(0, 9); ctx.lineTo(9, -1); ctx.stroke(); break;
    case "jet":
      ctx.moveTo(0, -10); ctx.quadraticCurveTo(6, -4, 5, 4); ctx.lineTo(-5, 4); ctx.quadraticCurveTo(-6, -4, 0, -10); ctx.fill();
      ctx.beginPath(); ctx.moveTo(-3, 7); ctx.lineTo(0, 11); ctx.lineTo(3, 7); ctx.stroke(); break;
    case "slow":
      ctx.arc(0, 0, 9, 0, 7); ctx.stroke(); ctx.beginPath(); ctx.moveTo(0, -5); ctx.lineTo(0, 0); ctx.lineTo(4, 3); ctx.stroke(); break;
    case "x2":
      ctx.font = "800 17px ui-sans-serif, system-ui, sans-serif"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
      ctx.fillText("×2", 0, 1); break;
    case "clear":
      ctx.moveTo(0, -10); ctx.lineTo(2.5, -2.5); ctx.lineTo(10, 0); ctx.lineTo(2.5, 2.5); ctx.lineTo(0, 10);
      ctx.lineTo(-2.5, 2.5); ctx.lineTo(-10, 0); ctx.lineTo(-2.5, -2.5); ctx.closePath(); ctx.fill(); break;
    default: // « rush » et pouvoirs de personnage : éclair
      ctx.moveTo(3, -10); ctx.lineTo(-6, 2); ctx.lineTo(0, 2); ctx.lineTo(-3, 10); ctx.lineTo(7, -3); ctx.lineTo(1, -3); ctx.closePath(); ctx.fill();
  }
  ctx.restore();
}
function drawPick(p) {
  const y = p.y + Math.sin(s.t / 12 + p.ph) * 4;
  ctx.save(); ctx.translate(p.x, y); ctx.fillStyle = TEAL;
  ctx.globalAlpha = 0.25 + 0.15 * Math.sin(s.t / 8 + p.ph); ctx.beginPath(); ctx.arc(0, 0, 21, 0, 7); ctx.fill();
  ctx.globalAlpha = 1; ctx.beginPath(); ctx.arc(0, 0, 15, 0, 7); ctx.fill();
  drawIcon(p.type, 0, 0, 16, "#fff");
  ctx.restore();
}
function drawChips(ink) {                                    // effets actifs, en haut à gauche
  const a = [];
  if (s.shield) a.push(["shield", 1]);
  if (s.revive) a.push(["revive", 1]);
  for (const key in s.fx) if (s.fx[key] > 0) a.push([BOOSTS[key] ? key : "power", s.fx[key] / s.fxMax[key]]);
  a.forEach(([t, f], i) => {
    const x = 30 + i * 38, y = 58;
    ctx.fillStyle = TEAL; ctx.beginPath(); ctx.arc(x + 14, y + 14, 14, 0, 7); ctx.fill();
    drawIcon(t, x + 14, y + 14, 14, "#fff");
    if (f < 1) {
      ctx.fillStyle = ink; ctx.globalAlpha = 0.25; ctx.fillRect(x, y + 32, 28, 3); ctx.globalAlpha = 1;
      ctx.fillStyle = TEAL; ctx.fillRect(x, y + 32, 28 * f, 3);
    }
  });
}
function drawPower(ink, bg) {                                // jauge + bouton du pouvoir (touche X / Shift, ou toucher)
  const p = cur().power, cx = W - 44, cy = H - 30, r = 17, ready = s.gauge >= 1;
  ctx.save();
  ctx.fillStyle = ready ? TEAL : bg; ctx.beginPath(); ctx.arc(cx, cy, r, 0, 7); ctx.fill();
  ctx.lineWidth = 3; ctx.strokeStyle = ink; ctx.globalAlpha = 0.25; ctx.beginPath(); ctx.arc(cx, cy, r, 0, 7); ctx.stroke();
  ctx.globalAlpha = 1;
  if (!ready) {
    ctx.strokeStyle = TEAL; ctx.beginPath(); ctx.arc(cx, cy, r, -Math.PI / 2, -Math.PI / 2 + s.gauge * Math.PI * 2); ctx.stroke();
    drawIcon("power", cx, cy, 14, ink); 
  } else {
    drawIcon("power", cx, cy, 14, "#fff");
    ctx.strokeStyle = TEAL; ctx.globalAlpha = 0.5 * Math.abs(Math.sin(s.t / 12));
    ctx.beginPath(); ctx.arc(cx, cy, r + 5, 0, 7); ctx.stroke(); ctx.globalAlpha = 1;
    ctx.fillStyle = ink; ctx.textAlign = "right"; ctx.font = "600 13px ui-sans-serif, system-ui, sans-serif";
    ctx.fillText(p.name + " · X", cx - r - 10, cy + 5);
  }
  ctx.restore();
}

function drawSpeaker(ink) {
  ctx.save(); ctx.translate(W - 44, 84); ctx.fillStyle = ink; ctx.strokeStyle = ink; ctx.lineWidth = 2; ctx.lineCap = "round";
  ctx.globalAlpha = 0.6;
  ctx.beginPath(); ctx.moveTo(0, 4); ctx.lineTo(5, 4); ctx.lineTo(11, 0); ctx.lineTo(11, 14); ctx.lineTo(5, 10); ctx.lineTo(0, 10); ctx.closePath(); ctx.fill();
  ctx.beginPath();
  if (muted) { ctx.moveTo(15, 3); ctx.lineTo(23, 11); ctx.moveTo(23, 3); ctx.lineTo(15, 11); }
  else { ctx.arc(11, 7, 6, -0.9, 0.9); ctx.moveTo(11 + 10 * Math.cos(-0.9), 7 + 10 * Math.sin(-0.9)); ctx.arc(11, 7, 10, -0.9, 0.9); }
  ctx.stroke(); ctx.restore();
}

function draw() {
  // jour/nuit : 0 = jour, 1 = nuit (cycle de ~1200 points)
  const n = (1 - Math.cos(s.score / 1200 * Math.PI * 2)) / 2;
  const bg = col("bg", n), ink = col("ink", n);
  document.body.style.background = bg;

  ctx.save();
  if (s.shake > 0) ctx.translate(rnd(-1, 1) * s.shake * 0.5, rnd(-1, 1) * s.shake * 0.5);
  ctx.fillStyle = bg; ctx.fillRect(-20, -20, W + 40, H + 40);

  // étoiles, soleil/lune
  ctx.fillStyle = "#fff";
  if (n > 0.3) s.stars.forEach(t => {
    ctx.globalAlpha = (n - 0.3) * (0.5 + 0.5 * Math.sin(s.t / 30 + t.p));
    ctx.beginPath(); ctx.arc(t.x, t.y, t.r, 0, 7); ctx.fill();
  });
  ctx.globalAlpha = 1;
  ctx.fillStyle = mix(ACCENT, "#E8E8E4", n); ctx.globalAlpha = 0.9;
  ctx.beginPath(); ctx.arc(760, 70, 20, 0, 7); ctx.fill(); ctx.globalAlpha = 1;

  // nuages
  ctx.fillStyle = col("far", n);
  s.clouds.forEach(c => roundRect(c.x, c.y, c.w, 14, 7));

  // collines parallaxe (2 couches)
  [["far", 0.12, 70, 120], ["near", 0.3, 40, 80]].forEach(([k, sp, amp, per]) => {
    ctx.fillStyle = col(k, n); ctx.beginPath(); ctx.moveTo(0, GY);
    for (let x = 0; x <= W; x += 10) ctx.lineTo(x, GY - 20 - amp * 0.5 - amp * 0.5 * Math.sin((x + s.dist * sp) / per * 2));
    ctx.lineTo(W, GY); ctx.fill();
  });

  // sol
  ctx.fillStyle = ink; ctx.globalAlpha = 0.85; ctx.fillRect(0, GY, W, 2);
  ctx.globalAlpha = 0.35;
  for (let i = 0; i < 30; i++) {
    const x = ((i * 97 - s.dist) % (W + 60) + W + 60) % (W + 60) - 30;
    ctx.fillRect(x, GY + 10 + (i % 4) * 8, 6 + (i % 3) * 6, 2);
  }
  ctx.globalAlpha = 1;

  s.obs.forEach(o => drawObs(o, n));
  s.picks.forEach(p => drawPick(p));
  s.waves.forEach(w => {
    ctx.save(); ctx.strokeStyle = TEAL; ctx.lineWidth = 4; ctx.globalAlpha = Math.max(0, 1 - w.r / w.max);
    ctx.beginPath(); ctx.arc(w.x, w.y, w.r, w.full ? 0 : -1.1, w.full ? 7 : 1.1); ctx.stroke(); ctx.restore();
  });
  s.beams.forEach(b => {
    ctx.save(); ctx.lineCap = "round"; ctx.globalAlpha = Math.min(1, b.t / 8); ctx.strokeStyle = TEAL; ctx.lineWidth = 7;
    ctx.beginPath(); ctx.moveTo(b.x1, b.y1); ctx.lineTo(b.x2, b.y2); ctx.stroke();
    ctx.strokeStyle = "#fff"; ctx.lineWidth = 2; ctx.stroke(); ctx.restore();
  });
  s.dust.forEach(d => { ctx.globalAlpha = d.c ? Math.min(1, d.l) : d.l * 0.5; ctx.fillStyle = d.c || ink; ctx.beginPath(); ctx.arc(d.x, d.y, d.r || 2.5, 0, 7); ctx.fill(); });
  ctx.globalAlpha = 1;
  drawDino(n);
  ctx.restore();

  // HUD
  ctx.textAlign = "right"; ctx.fillStyle = ink;
  ctx.font = "700 28px ui-monospace, 'SF Mono', Consolas, monospace";
  ctx.fillStyle = s.fx.x2 > 0 ? TEAL : ink;
  ctx.fillText(String(Math.floor(s.score)).padStart(5, "0"), W - 24, 44);
  ctx.fillStyle = ink;
  ctx.globalAlpha = 0.5; ctx.font = "500 14px ui-monospace, Consolas, monospace";
  ctx.fillText("MEILLEUR " + String(best).padStart(5, "0"), W - 24, 66); ctx.globalAlpha = 1;

  ctx.textAlign = "left";
  if (!navigator.onLine) {
    ctx.fillStyle = ACCENT; ctx.beginPath(); ctx.arc(30, 36, 5, 0, 7); ctx.fill();
    ctx.fillStyle = ink; ctx.font = "500 15px ui-sans-serif, system-ui, sans-serif"; ctx.fillText("Hors-ligne", 44, 41);
  }

  ctx.textAlign = "center"; ctx.fillStyle = ink;
  if (s.state === "idle") {
    ctx.font = "600 20px ui-sans-serif, system-ui, sans-serif"; ctx.fillText("Espace ou ↑ pour sauter", W / 2, 120);
    ctx.globalAlpha = 0.6; ctx.font = "400 15px ui-sans-serif, system-ui, sans-serif"; ctx.fillText("↓ pour se baisser · X ou Shift : pouvoir spécial", W / 2, 148); ctx.globalAlpha = 1;
  } else if (s.state === "dead") {
    ctx.font = "700 34px ui-sans-serif, system-ui, sans-serif"; ctx.fillText("Partie terminée", W / 2, 110);
    ctx.globalAlpha = 0.65; ctx.font = "400 16px ui-sans-serif, system-ui, sans-serif"; ctx.fillText("Espace pour rejouer", W / 2, 140); ctx.globalAlpha = 1;
  }
  if (s.state !== "run") {
    ctx.fillStyle = ink; ctx.font = "600 18px ui-sans-serif, system-ui, sans-serif";
    ctx.fillText("‹    " + cur().name + "  ·  " + cur().power.name + "    ›", W / 2, 196);
    ctx.globalAlpha = 0.5; ctx.font = "400 13px ui-sans-serif, system-ui, sans-serif";
    ctx.fillText("← → pour changer de personnage · M pour le son", W / 2, 218);
    const nx = CHARS.filter(c => !unlocked(c)).sort((a, b) => a.at - b.at)[0];
    if (nx) {
      ctx.textAlign = "left";
      ctx.fillText("Prochain personnage : " + nx.name + " à " + nx.at + " pts", 30, 66);
      ctx.textAlign = "center";
    }
    ctx.globalAlpha = 1;
  }
  if (s.state !== "run") drawSpeaker(ink);
  if (s.state === "run") drawChips(ink);
  drawPower(ink, bg);
  if (s.toast && s.toast.t > 0) {
    ctx.globalAlpha = Math.min(1, s.toast.t / 30); ctx.fillStyle = s.toast.c || ACCENT; roundRect(W / 2 - 120, 16, 240, 34, 17);
    ctx.fillStyle = "#fff"; ctx.font = "700 16px ui-sans-serif, system-ui, sans-serif";
    ctx.fillText(s.toast.text, W / 2, 38); ctx.globalAlpha = 1;
  }
  if (banner.t > 0) {
    const bw = banner.persist ? 440 : 240;
    ctx.globalAlpha = Math.min(1, banner.t / 30); ctx.fillStyle = ink; roundRect(W / 2 - bw / 2, 58, bw, 32, 16);
    ctx.fillStyle = bg; ctx.font = "600 14px ui-sans-serif, system-ui, sans-serif"; ctx.fillText(banner.text, W / 2, 78); ctx.globalAlpha = 1;
  }
  if (s.flash > 0) { ctx.fillStyle = ACCENT; ctx.globalAlpha = s.flash * 0.35; ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 1; }
}

let last = performance.now();
function loop(now) {
  const k = Math.min((now - last) / 16.667, 2); last = now;
  update(k); draw(); requestAnimationFrame(loop);
}
requestAnimationFrame(loop);
