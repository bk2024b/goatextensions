// Détection hors-ligne : quand une page échoue à charger parce qu'il n'y a pas d'internet,
// on réagit selon le mode choisi dans les options (notification, pastille, ouverture auto, rien).
const GAME = chrome.runtime.getURL("game.html");
const PROBE = "https://cp.cloudflare.com/generate_204"; // petit ping pour confirmer qu'on est vraiment hors-ligne
const OFFLINE_ERR = /ERR_(INTERNET_DISCONNECTED|NETWORK_CHANGED|NAME_NOT_RESOLVED|CONNECTION_(FAILED|TIMED_OUT|RESET))/;
const isWeb = url => /^https?:/.test(url);

// Wi-Fi connecté mais sans internet : navigator.onLine ment, donc on vérifie par une vraie requête.
async function reallyOffline() {
  if (!navigator.onLine) return true;
  const ctrl = new AbortController(), timer = setTimeout(() => ctrl.abort(), 4000);
  try { await fetch(PROBE, { mode: "no-cors", cache: "no-store", signal: ctrl.signal }); return false; }
  catch { return true; }
  finally { clearTimeout(timer); }
}

const openGame = () => chrome.tabs.create({ url: GAME });
chrome.action.onClicked.addListener(openGame);

chrome.webNavigation.onErrorOccurred.addListener(async d => {
  if (d.frameId !== 0 || !isWeb(d.url) || !OFFLINE_ERR.test(d.error)) return;
  const { mode } = await chrome.storage.local.get({ mode: "notify" });
  if (mode === "off" || !(await reallyOffline())) return;

  await chrome.storage.session.set({ ["origin:" + d.tabId]: d.url }); // pour proposer « recharger » au retour du réseau
  if (mode === "auto") { chrome.tabs.update(d.tabId, { url: GAME }); return; }

  chrome.action.setBadgeBackgroundColor({ tabId: d.tabId, color: "#FF6B35" });
  chrome.action.setBadgeText({ tabId: d.tabId, text: "▶" });
  if (mode !== "notify") return;

  const { notified } = await chrome.storage.session.get("notified"); // une seule notification par coupure
  if (notified) return;
  await chrome.storage.session.set({ notified: true });
  chrome.notifications.create("offline", {
    type: "basic", iconUrl: "icons/icon128.png",
    title: "Pas de connexion", message: "Un petit run en attendant que ça revienne ?",
    buttons: [{ title: "Jouer" }],
  });
});

// Retour du réseau : on nettoie la notification et la pastille.
chrome.webNavigation.onCompleted.addListener(async d => {
  if (d.frameId !== 0 || !isWeb(d.url)) return;
  const { notified } = await chrome.storage.session.get("notified");
  if (notified) { await chrome.storage.session.remove("notified"); chrome.notifications.clear("offline"); }
  chrome.action.setBadgeText({ tabId: d.tabId, text: "" });
});

chrome.notifications.onClicked.addListener(id => { openGame(); chrome.notifications.clear(id); });
chrome.notifications.onButtonClicked.addListener(id => { openGame(); chrome.notifications.clear(id); });
chrome.tabs.onRemoved.addListener(tabId => chrome.storage.session.remove("origin:" + tabId));
