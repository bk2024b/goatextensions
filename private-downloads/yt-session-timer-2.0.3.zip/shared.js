// Helpers partagés (service worker, page YouTube, popup, options) + rendu du panneau.
// Le niveau supérieur ne touche jamais au DOM : le service worker peut l'importer.
const YTS = (() => {
  'use strict';

  const pad = (n) => String(n).padStart(2, '0');
  const dayKey = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

  const SESSION_GAP = 30 * 60 * 1000;
  const KEEP_DAYS = 365;
  const DETAIL_DAYS = 120;
  const TOP_KEEP = 25;
  const DEFAULTS = {
    showPill: true,
    showBadge: true,
    countBackground: true,
    trackDetails: true,
    limitMin: 0,
    breakMin: 0,
  };
  const CATS = ['v', 's', 'm', 'b'];
  const CAT_LABEL = { v: 'cat_video', s: 'cat_shorts', m: 'cat_music', b: 'cat_browse' };

  /* ---------- i18n ---------- */
  const lang = () => {
    try { return chrome.i18n.getUILanguage(); } catch (e) { return 'en'; }
  };
  const t = (key, vars) => {
    let s = '';
    try { s = chrome.i18n.getMessage(key); } catch (e) { /* hors extension */ }
    s = s || key;
    if (vars) for (const k of Object.keys(vars)) s = s.split('{' + k + '}').join(String(vars[k]));
    return s;
  };

  /* ---------- formats ---------- */
  const fmt = (s) => {
    s = Math.max(0, Math.round(s));
    if (s < 60) return `${s} s`;
    const m = Math.floor(s / 60);
    if (m < 60) return `${m} min`;
    const h = Math.floor(m / 60);
    const r = m % 60;
    return r ? `${h} h ${pad(r)} min` : `${h} h`;
  };
  const fmtBadge = (s) => {
    const m = Math.floor(Math.max(0, s) / 60);
    if (m < 60) return `${m}m`;
    return `${Math.floor(m / 60)}h${pad(m % 60)}`;
  };

  /* ---------- données ---------- */
  // Les anciennes versions ne stockaient que { total, watch } : on les convertit à la lecture.
  const cats = (d) => {
    if (!d) return { v: 0, s: 0, m: 0, b: 0 };
    if (d.c) return { v: d.c.v || 0, s: d.c.s || 0, m: d.c.m || 0, b: d.c.b || 0 };
    return { v: d.watch || 0, s: 0, m: 0, b: Math.max(0, (d.total || 0) - (d.watch || 0)) };
  };

  const load = async () => {
    const o = await chrome.storage.local.get(['stats', 'session', 'settings']);
    return {
      stats: o.stats || {},
      session: o.session || null,
      settings: { ...DEFAULTS, ...(o.settings || {}) },
    };
  };

  const dayList = (n, offset = 0, now = new Date()) =>
    Array.from({ length: n }, (_, i) =>
      new Date(now.getFullYear(), now.getMonth(), now.getDate() - (n - 1 - i) - offset));

  const sumRange = (stats, days) =>
    days.reduce((a, d) => {
      const v = stats[dayKey(d)];
      if (v) {
        const c = cats(v);
        a.total += v.total || 0;
        a.v += c.v; a.s += c.s; a.m += c.m; a.b += c.b;
        a.bg += v.bg || 0;
      }
      return a;
    }, { total: 0, v: 0, s: 0, m: 0, b: 0, bg: 0 });

  const summary = ({ stats, session }) => {
    const now = new Date();
    const raw = stats[dayKey(now)] || null;
    const today = { total: raw ? raw.total || 0 : 0, bg: raw ? raw.bg || 0 : 0, c: cats(raw) };
    const week = dayList(7, 0, now).map((d, i) => {
      const v = stats[dayKey(d)];
      return { date: d, total: v ? v.total || 0 : 0, today: i === 6 };
    });
    const weekTotal = week.reduce((a, b) => a + b.total, 0);
    const prevTotal = sumRange(stats, dayList(7, 7, now)).total;
    const live = session && Date.now() - session.last < SESSION_GAP ? session.seconds : 0;
    return { today, week, weekTotal, prevTotal, avg: weekTotal / 7, session: live };
  };

  const loadDetails = async (days) => {
    const keys = days.map((d) => 'd:' + dayKey(d));
    const o = await chrome.storage.local.get(keys);
    const out = { ch: {}, ar: {}, vd: {} };
    for (const k of keys) {
      const d = o[k];
      if (!d) continue;
      for (const [n, s] of Object.entries(d.ch || {})) out.ch[n] = (out.ch[n] || 0) + s;
      for (const [n, s] of Object.entries(d.ar || {})) out.ar[n] = (out.ar[n] || 0) + s;
      for (const [id, v] of Object.entries(d.vd || {})) {
        const e = out.vd[id] || (out.vd[id] = { n: v.n, s: 0 });
        e.s += v.s;
      }
    }
    return out;
  };

  const topN = (obj, n = 5) =>
    Object.entries(obj)
      .map(([k, v]) => (typeof v === 'number' ? { k, n: k, s: v } : { k, n: v.n, s: v.s }))
      .sort((a, b) => b.s - a.s)
      .slice(0, n);

  /* ---------- export / reset ---------- */
  const download = (name, text, type) => {
    const a = document.createElement('a');
    const url = URL.createObjectURL(new Blob([text], { type }));
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  const exportData = async (kind) => {
    const all = await chrome.storage.local.get(null);
    const stats = all.stats || {};
    const stamp = dayKey(new Date());
    if (kind === 'csv') {
      const rows = ['date,total_s,videos_s,shorts_s,music_s,browsing_s,background_s'];
      for (const day of Object.keys(stats).sort()) {
        const v = stats[day];
        const c = cats(v);
        rows.push([day, v.total || 0, c.v, c.s, c.m, c.b, v.bg || 0].join(','));
      }
      download(`youtube-session-timer-${stamp}.csv`, rows.join('\n') + '\n', 'text/csv');
    } else {
      const details = {};
      for (const k of Object.keys(all)) if (k.startsWith('d:')) details[k.slice(2)] = all[k];
      const data = { exportedAt: new Date().toISOString(), stats, details };
      download(`youtube-session-timer-${stamp}.json`, JSON.stringify(data, null, 2), 'application/json');
    }
  };

  /* ---------- DOM ---------- */
  const el = (tag, cls, text) => {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  };

  const icon = (size = 24) => {
    const ns = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(ns, 'svg');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('width', size);
    svg.setAttribute('height', size);
    svg.setAttribute('fill', 'currentColor');
    svg.setAttribute('focusable', 'false');
    const p = document.createElementNS(ns, 'path');
    p.setAttribute('d', 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z');
    svg.appendChild(p);
    return svg;
  };

  const gear = () => {
    const ns = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(ns, 'svg');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('width', 18);
    svg.setAttribute('height', 18);
    svg.setAttribute('fill', 'currentColor');
    svg.setAttribute('focusable', 'false');
    const p = document.createElementNS(ns, 'path');
    p.setAttribute('d', 'M19.43 12.98c.04-.32.07-.64.07-.98s-.03-.66-.07-.98l2.11-1.65a.5.5 0 0 0 .12-.64l-2-3.46a.5.5 0 0 0-.61-.22l-2.49 1a7.3 7.3 0 0 0-1.69-.98l-.38-2.65A.49.49 0 0 0 14 2h-4a.49.49 0 0 0-.49.42l-.38 2.65c-.61.25-1.17.59-1.69.98l-2.49-1a.5.5 0 0 0-.61.22l-2 3.46a.5.5 0 0 0 .12.64l2.11 1.65c-.04.32-.07.65-.07.98s.03.66.07.98l-2.11 1.65a.5.5 0 0 0-.12.64l2 3.46c.12.22.39.3.61.22l2.49-1c.52.4 1.08.73 1.69.98l.38 2.65c.03.24.24.42.49.42h4c.25 0 .46-.18.49-.42l.38-2.65c.61-.25 1.17-.59 1.69-.98l2.49 1c.23.09.49 0 .61-.22l2-3.46a.5.5 0 0 0-.12-.64l-2.11-1.65zM12 15.5A3.5 3.5 0 1 1 12 8.5a3.5 3.5 0 0 1 0 7z');
    svg.appendChild(p);
    return svg;
  };

  const ui = { tab: 'today', histDays: 90, topDays: 7 };

  const cell = (label, value) => {
    const node = el('div', 'yts-cell');
    node.append(el('div', 'yts-cell-lab', label), el('div', 'yts-cell-val', value));
    return node;
  };

  const rangeButtons = (options, current, onPick) => {
    const row = el('div', 'yts-range');
    for (const [val, label] of options) {
      const b = el('button', 'yts-rbtn' + (val === current ? ' yts-rbtn-on' : ''), label);
      b.type = 'button';
      b.addEventListener('click', () => onPick(val));
      row.appendChild(b);
    }
    return row;
  };

  const buildToday = (data) => {
    const frag = document.createDocumentFragment();
    const s = summary(data);
    const { limitMin } = data.settings;

    frag.appendChild(el('div', 'yts-big', fmt(s.today.total)));

    const seg = el('div', 'yts-seg');
    for (const c of CATS) {
      const part = el('span', 'yts-c-' + c);
      part.style.width = (s.today.total ? (s.today.c[c] / s.today.total) * 100 : 0) + '%';
      seg.appendChild(part);
    }
    frag.appendChild(seg);

    const legend = el('div', 'yts-legend');
    for (const c of CATS) {
      const row = el('div', 'yts-lg');
      row.append(el('i', 'yts-lg-dot yts-c-' + c), el('span', '', t(CAT_LABEL[c])), el('b', '', fmt(s.today.c[c])));
      legend.appendChild(row);
    }
    frag.appendChild(legend);

    if (s.today.bg > 0) frag.appendChild(el('div', 'yts-note', t('bg_note', { t: fmt(s.today.bg) })));

    if (limitMin > 0) {
      const used = s.today.total;
      const lim = limitMin * 60;
      const box = el('div', 'yts-goal');
      const head = el('div', 'yts-goal-head');
      head.append(el('span', '', t('goal_label')), el('b', '', t('goal_value', { used: fmt(used), limit: fmt(lim) })));
      const bar = el('div', 'yts-goal-bar');
      const fill = el('span', used >= lim ? 'yts-over' : '');
      fill.style.width = Math.min(100, (used / lim) * 100) + '%';
      bar.appendChild(fill);
      box.append(head, bar);
      frag.appendChild(box);
    }

    frag.appendChild(el('div', 'yts-sep'));
    const grid = el('div', 'yts-grid');
    grid.append(cell(t('session'), fmt(s.session)), cell(t('avg_day'), fmt(s.avg)), cell(t('last7'), fmt(s.weekTotal)));
    frag.appendChild(grid);

    if (s.prevTotal > 0) {
      const pct = Math.round(((s.weekTotal - s.prevTotal) / s.prevTotal) * 100);
      const key = pct > 0 ? 'vs_prev_up' : pct < 0 ? 'vs_prev_down' : 'vs_prev_same';
      frag.appendChild(el('div', 'yts-note yts-cmp', t(key, { p: Math.abs(pct) })));
    }

    frag.appendChild(el('div', 'yts-sep'));
    const chart = el('div', 'yts-chart');
    const max = Math.max(1, ...s.week.map((d) => d.total));
    for (const d of s.week) {
      const col = el('div', 'yts-col');
      const bar = el('div', 'yts-bar' + (d.today ? ' yts-bar-today' : ''));
      bar.style.height = (d.total ? Math.max(4, Math.round((d.total / max) * 44)) : 2) + 'px';
      const lab = el('div', 'yts-col-lab' + (d.today ? ' yts-col-lab-today' : ''),
        d.date.toLocaleDateString(lang(), { weekday: 'narrow' }));
      col.title = d.date.toLocaleDateString(lang(), { weekday: 'long', day: 'numeric', month: 'long' }) + ' : ' + fmt(d.total);
      col.append(bar, lab);
      chart.appendChild(col);
    }
    frag.append(chart, el('div', 'yts-foot', t('foot')));
    return frag;
  };

  const buildHistory = (data, rerender) => {
    const frag = document.createDocumentFragment();
    const n = ui.histDays;
    const days = dayList(n);
    const totals = days.map((d) => (data.stats[dayKey(d)] || {}).total || 0);
    const sum = totals.reduce((a, b) => a + b, 0);
    const max = Math.max(...totals);
    const bestIdx = max > 0 ? totals.indexOf(max) : -1;

    frag.appendChild(rangeButtons(
      [[30, t('range_30')], [90, t('range_90')], [365, t('range_365')]],
      n,
      (v) => { ui.histDays = v; rerender(); }
    ));

    const grid = el('div', 'yts-grid');
    grid.append(
      cell(t('total'), fmt(sum)),
      cell(t('avg_day'), fmt(sum / n)),
      cell(t('best_day'), bestIdx >= 0
        ? days[bestIdx].toLocaleDateString(lang(), { day: 'numeric', month: 'short' }) + ' · ' + fmt(max)
        : '—')
    );
    frag.appendChild(grid);

    // barres empilées par catégorie ; au-delà de 90 jours on regroupe par semaine
    const step = n > 90 ? 7 : 1;
    const buckets = [];
    for (let i = 0; i < days.length; i += step) {
      const slice = days.slice(i, i + step);
      buckets.push({ first: slice[0], last: slice[slice.length - 1], agg: sumRange(data.stats, slice) });
    }
    const H = 110;
    const maxB = Math.max(1, ...buckets.map((x) => x.agg.total));
    const avgB = buckets.reduce((a, x) => a + x.agg.total, 0) / buckets.length;

    const top = el('div', 'yts-axis', fmt(maxB) + (step > 1 ? ' · ' + t('per_week') : ''));
    const wrap = el('div', 'yts-hist-wrap');
    const hist = el('div', 'yts-hist');
    hist.style.height = H + 'px';
    hist.style.gap = buckets.length > 60 ? '1px' : '2px';
    const dfmt = { day: 'numeric', month: 'short' };
    for (const bk of buckets) {
      const col = el('div', 'yts-hbar');
      const when = step > 1
        ? bk.first.toLocaleDateString(lang(), dfmt) + ' – ' + bk.last.toLocaleDateString(lang(), dfmt)
        : bk.first.toLocaleDateString(lang(), { weekday: 'long', day: 'numeric', month: 'long' });
      col.title = when + ' : ' + fmt(bk.agg.total);
      for (const c of ['b', 'm', 's', 'v']) {
        if (!bk.agg[c]) continue;
        const seg = el('span', 'yts-c-' + c);
        seg.style.height = Math.max(1, (bk.agg[c] / maxB) * H) + 'px';
        if (c === 'b') seg.style.background = 'var(--yts-track)';
        col.appendChild(seg);
      }
      hist.appendChild(col);
    }
    const avgLine = el('i', 'yts-avgline');
    avgLine.style.bottom = (avgB / maxB) * H + 'px';
    avgLine.title = t('avg_day');
    wrap.append(hist, avgLine);

    const ends = el('div', 'yts-axis yts-ends');
    ends.append(el('span', '', days[0].toLocaleDateString(lang(), dfmt)), el('span', '', days[days.length - 1].toLocaleDateString(lang(), dfmt)));

    const key = el('div', 'yts-histkey');
    for (const c of CATS) {
      const k = el('span', 'yts-hk');
      k.append(el('i', 'yts-lg-dot yts-c-' + c), document.createTextNode(t(CAT_LABEL[c])));
      key.appendChild(k);
    }
    frag.append(top, wrap, ends, key);

    const actions = el('div', 'yts-actions');
    for (const [kind, label] of [['csv', t('export_csv')], ['json', t('export_json')]]) {
      const b = el('button', 'yts-btn', label);
      b.type = 'button';
      b.addEventListener('click', () => exportData(kind));
      actions.appendChild(b);
    }
    frag.appendChild(actions);
    return frag;
  };

  const buildTop = async (data, rerender) => {
    const frag = document.createDocumentFragment();
    frag.appendChild(rangeButtons(
      [[1, t('range_today')], [7, t('range_7')], [30, t('range_30')]],
      ui.topDays,
      (v) => { ui.topDays = v; rerender(); }
    ));
    if (!data.settings.trackDetails) {
      frag.appendChild(el('div', 'yts-empty', t('top_disabled')));
      return frag;
    }
    const det = await loadDetails(dayList(ui.topDays));
    const sections = [
      ['top_channels', topN(det.ch), null],
      ['top_videos', topN(det.vd), (id) => `https://www.youtube.com/watch?v=${encodeURIComponent(id)}`],
      ['top_artists', topN(det.ar), null],
    ];
    let any = false;
    for (const [label, rows, link] of sections) {
      if (!rows.length) continue;
      any = true;
      frag.appendChild(el('div', 'yts-sect', t(label)));
      const top = rows[0].s || 1;
      for (const r of rows) {
        const row = el('div', 'yts-row');
        let name;
        if (link) {
          name = el('a', 'yts-rname', r.n);
          name.href = link(r.k);
          name.target = '_blank';
          name.rel = 'noopener noreferrer';
        } else {
          name = el('span', 'yts-rname', r.n);
        }
        name.title = r.n;
        const bar = el('div', 'yts-rbar');
        const fill = el('span');
        fill.style.width = Math.max(4, (r.s / top) * 100) + '%';
        bar.appendChild(fill);
        row.append(name, el('b', '', fmt(r.s)), bar);
        frag.appendChild(row);
      }
    }
    if (!any) frag.appendChild(el('div', 'yts-empty', t('top_empty')));
    return frag;
  };

  const buildPanel = async (root, data, opts) => {
    const rerender = () => renderPanel(root, root._data, root._opts);
    const panel = el('div', 'yts-panel');

    const head = el('div', 'yts-head');
    head.appendChild(el('div', 'yts-title', t('panel_title')));
    const gb = el('button', 'yts-iconbtn');
    gb.type = 'button';
    gb.title = t('settings');
    gb.setAttribute('aria-label', t('settings'));
    gb.appendChild(gear());
    gb.addEventListener('click', () => opts && opts.openOptions && opts.openOptions());
    head.appendChild(gb);

    const tabs = el('div', 'yts-tabs');
    tabs.setAttribute('role', 'tablist');
    for (const [id, label] of [['today', t('tab_today')], ['history', t('tab_history')], ['top', t('tab_top')]]) {
      const b = el('button', 'yts-tab' + (ui.tab === id ? ' yts-tab-on' : ''), label);
      b.type = 'button';
      b.setAttribute('role', 'tab');
      b.setAttribute('aria-selected', String(ui.tab === id));
      b.addEventListener('click', () => { ui.tab = id; rerender(); });
      tabs.appendChild(b);
    }

    const body = el('div', 'yts-body');
    if (ui.tab === 'today') body.appendChild(buildToday(data));
    else if (ui.tab === 'history') body.appendChild(buildHistory(data, rerender));
    else body.appendChild(await buildTop(data, rerender));

    panel.append(head, tabs, body);
    return panel;
  };

  const renderPanel = async (root, data, opts) => {
    root._data = data;
    root._opts = opts;
    const token = (root._tok = (root._tok || 0) + 1);
    const panel = await buildPanel(root, data, opts);
    if (token !== root._tok) return; // un rendu plus récent a pris le relais
    const old = root.querySelector('.yts-body');
    const keep = old ? old.scrollTop : 0;
    root.replaceChildren(panel);
    const fresh = root.querySelector('.yts-body');
    if (fresh) fresh.scrollTop = keep;
  };

  return {
    KEEP_DAYS, DETAIL_DAYS, TOP_KEEP, SESSION_GAP, DEFAULTS, CATS,
    pad, dayKey, lang, t, fmt, fmtBadge, cats, load, summary, el, icon, renderPanel, exportData,
  };
})();
