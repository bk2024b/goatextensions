const { t, DEFAULTS } = YTS;

for (const node of document.querySelectorAll('[data-i18n]')) node.textContent = t(node.dataset.i18n);
document.documentElement.lang = YTS.lang();
if (location.hash === '#welcome') document.getElementById('welcome').hidden = false;

const saved = document.getElementById('saved');
let settings = { ...DEFAULTS };
let timer = 0;

const flash = () => {
  saved.textContent = t('opt_saved');
  clearTimeout(timer);
  timer = setTimeout(() => (saved.textContent = ''), 1500);
};

const inputs = Array.from(document.querySelectorAll('[data-key]'));

chrome.storage.local.get('settings').then((o) => {
  settings = { ...DEFAULTS, ...(o.settings || {}) };
  for (const i of inputs) {
    if (i.type === 'checkbox') i.checked = !!settings[i.dataset.key];
    else i.value = settings[i.dataset.key];
  }
});

for (const i of inputs) {
  i.addEventListener('change', async () => {
    const key = i.dataset.key;
    if (i.type === 'checkbox') settings[key] = i.checked;
    else {
      const n = Math.max(0, Math.min(Number(i.max) || 1440, Math.round(Number(i.value) || 0)));
      i.value = n;
      settings[key] = n;
    }
    await chrome.storage.local.set({ settings });
    flash();
  });
}

document.getElementById('csv').addEventListener('click', () => YTS.exportData('csv'));
document.getElementById('json').addEventListener('click', () => YTS.exportData('json'));
document.getElementById('reset').addEventListener('click', async () => {
  if (!confirm(t('opt_reset_confirm'))) return;
  await chrome.storage.local.clear();
  settings = { ...DEFAULTS };
  for (const i of inputs) {
    if (i.type === 'checkbox') i.checked = !!settings[i.dataset.key];
    else i.value = settings[i.dataset.key];
  }
  try { await chrome.action.setBadgeText({ text: '' }); } catch (e) { /* ignoré */ }
});
