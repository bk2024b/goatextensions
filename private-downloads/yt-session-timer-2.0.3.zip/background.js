// Agrège les secondes envoyées (par paquets) par les onglets YouTube / YouTube Music.
// Chaque seconde calendaire n'est comptée qu'une fois, même avec plusieurs onglets actifs.
importScripts('shared.js');

const { dayKey, cats, fmtBadge, KEEP_DAYS, DETAIL_DAYS, TOP_KEEP, SESSION_GAP, DEFAULTS } = YTS;
const CAT_SET = new Set(YTS.CATS);
const STREAK_GAP = 120 * 1000; // une coupure > 2 min remet la série de lecture à zéro
const OVER_LIMIT_REPEAT = 15 * 60; // rappel toutes les 15 min au-delà de la limite

let queue = Promise.resolve();

const clip = (s, n) => Array.from(String(s || '')).slice(0, n).join('').trim();

function prune(map) {
  const keys = Object.keys(map);
  if (keys.length <= TOP_KEEP * 2) return;
  const val = (k) => (typeof map[k] === 'number' ? map[k] : map[k].s);
  keys.sort((a, b) => val(b) - val(a)).slice(TOP_KEEP).forEach((k) => delete map[k]);
}

async function updateBadge(stats, settings) {
  try {
    if (!settings.showBadge) {
      await chrome.action.setBadgeText({ text: '' });
      return;
    }
    const today = stats[dayKey(new Date())];
    await chrome.action.setBadgeBackgroundColor({ color: '#606060' });
    await chrome.action.setBadgeText({ text: today ? fmtBadge(today.total || 0) : '' });
  } catch (e) { /* badge indisponible : sans importance */ }
}

async function record(msg, tabId) {
  const o = await chrome.storage.local.get(['stats', 'session', 'settings', 'clock', 'streak', 'rem']);
  const settings = { ...DEFAULTS, ...(o.settings || {}) };
  const stats = o.stats || {};
  let session = o.session || null;
  let clock = o.clock || 0;
  const streak = o.streak || { sec: 0, last: 0, next: 0 };

  const nowSec = Math.floor(Date.now() / 1000);
  const raw = Array.isArray(msg.items) ? msg.items.slice(0, 150) : [];
  const accepted = [];
  raw
    .filter((it) => Array.isArray(it) && Number.isFinite(it[0]) && CAT_SET.has(it[1]))
    .sort((a, b) => a[0] - b[0])
    .forEach((it) => {
      const [sec, cat, hidden] = it;
      if (sec <= clock || sec > nowSec + 2) return;
      if (hidden && !settings.countBackground) return;
      accepted.push({ sec, cat, hidden: !!hidden });
      clock = sec;
    });
  if (!accepted.length) return;

  const meta = msg.meta || {};
  const details = {};
  let newDay = false;

  for (const a of accepted) {
    const ms = a.sec * 1000;
    const day = dayKey(new Date(ms));

    // jour de stats
    let d = stats[day];
    if (!d) {
      d = stats[day] = { total: 0, watch: 0, bg: 0, c: { v: 0, s: 0, m: 0, b: 0 } };
      newDay = true;
    } else if (!d.c) {
      d.c = cats(d);
      d.bg = d.bg || 0;
    }
    d.total += 1;
    if (a.cat !== 'b') d.watch += 1;
    d.c[a.cat] += 1;
    if (a.hidden) d.bg += 1;

    // session (pause > 30 min = nouvelle session)
    if (!session || ms - session.last > SESSION_GAP) session = { start: ms, seconds: 0, last: ms };
    session.seconds += 1;
    session.last = ms;

    // série de lecture continue (pour le rappel de pause)
    if (a.cat !== 'b') {
      if (!streak.last || ms - streak.last > STREAK_GAP) {
        streak.sec = 0;
        streak.next = settings.breakMin * 60;
      }
      streak.sec += 1;
      streak.last = ms;
    }

    // détails : chaînes, vidéos, artistes
    if (settings.trackDetails && a.cat !== 'b') details[day] = true; // jour à charger plus bas
  }

  // chargement des détails des jours concernés
  if (settings.trackDetails) {
    const days = Object.keys(details);
    if (days.length) {
      const loaded = await chrome.storage.local.get(days.map((x) => 'd:' + x));
      for (const day of days) details[day] = loaded['d:' + day] || { ch: {}, ar: {}, vd: {} };
      for (const a of accepted) {
        if (a.cat === 'b') continue;
        const dt = details[dayKey(new Date(a.sec * 1000))];
        const ch = clip(meta.ch, 80);
        const ar = clip(meta.ar, 80);
        if (ch && (a.cat === 'v' || a.cat === 's')) dt.ch[ch] = (dt.ch[ch] || 0) + 1;
        if (ar && a.cat === 'm') dt.ar[ar] = (dt.ar[ar] || 0) + 1;
        if (a.cat === 'v' && meta.vd && /^[\w-]{6,20}$/.test(meta.vd.id || '')) {
          const e = dt.vd[meta.vd.id] || (dt.vd[meta.vd.id] = { n: clip(meta.vd.n, 100) || meta.vd.id, s: 0 });
          e.s += 1;
        }
      }
      for (const dt of Object.values(details)) { prune(dt.ch); prune(dt.ar); prune(dt.vd); }
    }
  }

  // nettoyage des vieux jours (une fois par nouveau jour)
  const removeKeys = [];
  if (newDay) {
    const now = new Date();
    const cutoff = new Date(now.getFullYear(), now.getMonth(), now.getDate() - KEEP_DAYS).getTime();
    for (const k of Object.keys(stats)) {
      if (new Date(k + 'T00:00:00').getTime() < cutoff) delete stats[k];
    }
    for (let i = 1; i <= 10; i++) {
      removeKeys.push('d:' + dayKey(new Date(now.getFullYear(), now.getMonth(), now.getDate() - DETAIL_DAYS - i)));
    }
  }

  // rappels : limite quotidienne et pause
  const today = dayKey(new Date());
  const todayTotal = (stats[today] || {}).total || 0;
  let rem = o.rem;
  if (!rem || rem.day !== today || rem.lim !== settings.limitMin) {
    rem = { day: today, lim: settings.limitMin, next: settings.limitMin * 60 };
  }
  const toasts = [];
  if (settings.limitMin > 0 && todayTotal >= rem.next) {
    toasts.push({ type: 'toast', kind: 'limit', used: todayTotal, limit: settings.limitMin * 60 });
    rem.next = todayTotal + OVER_LIMIT_REPEAT;
  }
  if (settings.breakMin > 0 && streak.sec >= (streak.next || settings.breakMin * 60)) {
    toasts.push({ type: 'toast', kind: 'break', minutes: Math.round(streak.sec / 60) });
    streak.next = streak.sec + settings.breakMin * 60;
  }

  const write = { stats, session, clock, streak, rem };
  for (const [day, dt] of Object.entries(details)) write['d:' + day] = dt;
  if (removeKeys.length) await chrome.storage.local.remove(removeKeys);
  await chrome.storage.local.set(write);
  await updateBadge(stats, settings);

  if (tabId != null) {
    for (const m of toasts) chrome.tabs.sendMessage(tabId, m).catch(() => {});
  }
}

chrome.runtime.onMessage.addListener((msg, sender) => {
  if (!msg) return;
  if (msg.type === 'flush') {
    const tabId = sender && sender.tab ? sender.tab.id : null;
    queue = queue.then(() => record(msg, tabId)).catch(() => {});
  } else if (msg.type === 'options') {
    chrome.runtime.openOptionsPage();
  }
});

async function refreshBadge() {
  const o = await chrome.storage.local.get(['stats', 'settings']);
  await updateBadge(o.stats || {}, { ...DEFAULTS, ...(o.settings || {}) });
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.settings) refreshBadge();
});

function ensureAlarm() {
  chrome.alarms.get('badge', (a) => {
    if (!a) chrome.alarms.create('badge', { periodInMinutes: 5 });
  });
}
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'badge') refreshBadge(); });
chrome.runtime.onStartup.addListener(() => { ensureAlarm(); refreshBadge(); });
chrome.runtime.onInstalled.addListener((info) => {
  ensureAlarm();
  refreshBadge();
  if (info.reason === 'install') {
    chrome.tabs.create({ url: chrome.runtime.getURL('options.html#welcome') });
  }
});
