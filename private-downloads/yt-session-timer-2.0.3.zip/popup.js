const root = document.getElementById('root');
const opts = { openOptions: () => { chrome.runtime.openOptionsPage(); window.close(); } };
let data = { stats: {}, session: null, settings: { ...YTS.DEFAULTS } };

YTS.load().then((d) => {
  data = d;
  YTS.renderPanel(root, data, opts);
});

chrome.storage.onChanged.addListener((c, area) => {
  if (area !== 'local' || !(c.stats || c.session || c.settings)) return;
  data = {
    stats: c.stats ? c.stats.newValue || {} : data.stats,
    session: c.session ? c.session.newValue : data.session,
    settings: c.settings ? { ...YTS.DEFAULTS, ...(c.settings.newValue || {}) } : data.settings,
  };
  YTS.renderPanel(root, data, opts);
});
