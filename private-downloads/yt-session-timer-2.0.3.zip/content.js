(() => {
  if (window.top !== window || window.__ytsLoaded) return;
  window.__ytsLoaded = true;

  const { el, icon, fmt, t, load, summary, renderPanel, DEFAULTS } = YTS;
  const IS_MUSIC = location.hostname === 'music.youtube.com';
  const IDLE_MS = 2 * 60 * 1000;      // inactif au-delà de 2 min (hors lecture)
  const FLUSH_EVERY = 5;              // secondes par paquet envoyé au service worker
  const MAX_CATCHUP = 5;              // secondes rattrapées après un tick manqué
  const MAX_CATCHUP_BG = 70;          // onglet masqué en lecture : le navigateur ralentit les timers

  let lastActivity = Date.now();
  let open = false;
  let data = { stats: {}, session: null, settings: { ...DEFAULTS } };
  const startedAt = Date.now();

  const bump = () => (lastActivity = Date.now());
  for (const ev of ['mousemove', 'keydown', 'wheel', 'click', 'touchstart']) {
    window.addEventListener(ev, bump, { passive: true, capture: true });
  }

  /* ---------- UI ---------- */
  const host = el('div', 'yts-host yts-scope' + (IS_MUSIC ? ' yts-dark' : ''));
  const pill = el('button', 'yts-pill');
  pill.type = 'button';
  pill.setAttribute('aria-label', t('panel_title'));
  pill.setAttribute('aria-expanded', 'false');

  const ico = el('span', 'yts-ico');
  ico.append(icon(24), el('i', 'yts-dot'));
  const label = el('span', 'yts-label', '0 s');
  pill.append(ico, label);

  // Le panneau vit dans <body>, pas dans la barre YouTube : aucun ancêtre (transform, overflow…)
  // ne peut le décaler ou le rogner, il se place toujours sous l'icône.
  const dropdown = el('div', 'yts-dropdown yts-scope' + (IS_MUSIC ? ' yts-dark' : ''));
  host.appendChild(pill);
  const attachDropdown = () => { if (!dropdown.isConnected && document.body) document.body.appendChild(dropdown); };

  const panelOpts = { openOptions: () => { try { chrome.runtime.sendMessage({ type: 'options' }); } catch (e) { /* ignoré */ } } };

  const paint = () => {
    label.textContent = fmt(summary(data).today.total);
    host.style.display = data.settings.showPill ? '' : 'none';
    if (open) renderPanel(dropdown, data, panelOpts).then(place);
  };

  const place = () => {
    const r = pill.getBoundingClientRect();
    const w = dropdown.offsetWidth || 340;
    const left = Math.min(Math.max(8, r.right - w), window.innerWidth - w - 8);
    dropdown.style.top = Math.round(r.bottom + 8) + 'px';
    dropdown.style.left = Math.round(left) + 'px';
  };

  const setOpen = (v) => {
    open = v;
    attachDropdown();
    dropdown.classList.toggle('yts-show', v);
    pill.setAttribute('aria-expanded', String(v));
    if (v) { renderPanel(dropdown, data, panelOpts).then(place); place(); }
  };

  pill.addEventListener('click', (e) => { e.stopPropagation(); setOpen(!open); });
  // Un clic dans le panneau ne doit jamais le fermer (le panneau se redessine, le bouton cliqué disparaît du DOM).
  dropdown.addEventListener('click', (e) => e.stopPropagation());
  document.addEventListener('click', () => { if (open) setOpen(false); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && open) setOpen(false); });
  window.addEventListener('resize', () => { if (open) place(); });
  window.addEventListener('scroll', () => { if (open) place(); }, { passive: true });

  chrome.storage.onChanged.addListener((c, area) => {
    if (area !== 'local') return;
    if (!(c.stats || c.session || c.settings)) return;
    data = {
      stats: c.stats ? c.stats.newValue || {} : data.stats,
      session: c.session ? c.session.newValue : data.session,
      settings: c.settings ? { ...DEFAULTS, ...(c.settings.newValue || {}) } : data.settings,
    };
    paint();
  });

  /* ---------- Injection dans la barre ---------- */
  const mount = () => {
    const target = document.querySelector(
      IS_MUSIC ? 'ytmusic-nav-bar #right-content, ytmusic-nav-bar .right-content' : 'ytd-masthead #end'
    );
    if (target) {
      if (host.parentElement !== target) {
        const anchor = IS_MUSIC ? target.firstChild : target.querySelector('#buttons') || target.firstChild;
        target.insertBefore(host, anchor);
        host.classList.remove('yts-floating');
      }
    } else if (!host.isConnected && Date.now() - startedAt > 8000) {
      // barre introuvable (refonte de l'interface) : pastille flottante en dernier recours
      host.classList.add('yts-floating');
      document.body.appendChild(host);
    }
  };

  /* ---------- Toasts de rappel ---------- */
  const toast = (msg) => {
    const text = msg.kind === 'limit'
      ? t('toast_limit', { used: fmt(msg.used), limit: fmt(msg.limit) })
      : t('toast_break', { n: msg.minutes });
    const box = el('div', 'yts-toast yts-scope' + (IS_MUSIC ? ' yts-dark' : ''));
    box.setAttribute('role', 'status');
    const close = el('button', 'yts-toast-x', '×');
    close.type = 'button';
    close.setAttribute('aria-label', t('toast_close'));
    close.addEventListener('click', () => box.remove());
    box.append(el('span', '', text), close);
    document.body.appendChild(box);
    setTimeout(() => box.remove(), 15000);
  };
  chrome.runtime.onMessage.addListener((msg) => { if (msg && msg.type === 'toast') toast(msg); });

  /* ---------- Détection de ce qui se passe ---------- */
  // YouTube conserve plusieurs lecteurs (watch, Shorts préchargés, aperçus).
  // Rechercher le lecteur de la surface active, jamais le premier <video> du DOM.
  const SHORT_RENDERERS = 'ytd-reel-video-renderer, ytd-shorts-video-renderer';
  const isShortsPath = () => /^\/shorts(?:\/|$)/.test(location.pathname);
  const isPlaying = (v) => !!v && !v.paused && !v.ended && v.readyState > 2;

  const visibleArea = (node) => {
    if (!node || node.closest('[hidden], [aria-hidden="true"]')) return 0;
    const style = getComputedStyle(node);
    if (style.display === 'none' || style.visibility === 'hidden') return 0;
    const r = node.getBoundingClientRect();
    return Math.max(0, Math.min(r.right, window.innerWidth) - Math.max(r.left, 0)) *
      Math.max(0, Math.min(r.bottom, window.innerHeight) - Math.max(r.top, 0));
  };

  const shortRenderer = () => Array.from(document.querySelectorAll(SHORT_RENDERERS))
    .map((node) => ({ node, area: visibleArea(node) }))
    .filter(({ area }) => area > 0)
    .sort((a, b) => b.area - a.area ||
      Number(b.node.hasAttribute('is-active') && b.node.getAttribute('is-active') !== 'false') -
      Number(a.node.hasAttribute('is-active') && a.node.getAttribute('is-active') !== 'false'))
    [0]?.node || null;

  const selectVideo = (root, shorts = false) => {
    const videos = Array.from(root.querySelectorAll('video')).filter((v) =>
      !v.closest('ytd-video-preview, ytd-moving-thumbnail-renderer') &&
      (shorts || !v.closest(SHORT_RENDERERS)) &&
      (shorts || IS_MUSIC || v.classList.contains('html5-main-video')));
    return videos.find(isPlaying) || videos[0] || null;
  };

  const playback = () => {
    if (IS_MUSIC) return { video: selectVideo(document), cat: 'm', root: document };
    if (isShortsPath()) {
      const root = shortRenderer();
      // Secours pour les variantes du lecteur qui n'utilisent pas de renderer.
      const video = root ? selectVideo(root, true) :
        Array.from(document.querySelectorAll('video')).filter((v) =>
          !v.closest('ytd-video-preview, ytd-moving-thumbnail-renderer') && visibleArea(v) > 0)
          .sort((a, b) => visibleArea(b) - visibleArea(a))[0] || null;
      return { video, cat: 's', root };
    }
    const watchLike = /^\/(?:watch|live)(?:\/|$)/.test(location.pathname) ||
      !!document.querySelector('ytd-miniplayer[active]');
    return { video: watchLike ? selectVideo(document) : null, cat: 'v', root: document };
  };

  const text = (sel, root = document) => {
    const n = root?.querySelector(sel);
    return n ? (n.textContent || '').trim() : '';
  };

  const meta = (cat, root = document) => {
    if (!data.settings.trackDetails) return {};
    if (cat === 'm') {
      let ar = text('ytmusic-player-bar .byline a[href*="channel/"]');
      if (!ar) ar = text('ytmusic-player-bar .byline').split('•')[0].trim();
      return ar ? { ar } : {};
    }
    if (cat === 's') {
      const ch = text('ytd-channel-name a', root) || text('#channel-name a', root) ||
        text('a[href^="/@"]', root) || text('a[href*="/channel/"]', root);
      return ch ? { ch } : {};
    }
    const out = {};
    const ch = text('ytd-watch-metadata ytd-channel-name a') || text('#owner #channel-name a');
    if (ch) out.ch = ch;
    const m = location.pathname.match(/^\/live\/([\w-]+)/);
    const id = m ? m[1] : location.pathname === '/watch' ? new URLSearchParams(location.search).get('v') : null;
    if (id) {
      const title = text('ytd-watch-metadata h1') ||
        document.title.replace(/^\(\d+\)\s*/, '').replace(/\s*-\s*YouTube$/, '');
      out.vd = { id, n: title };
    }
    return out;
  };

  /* ---------- Suivi du temps ---------- */
  const alive = () => {
    try { return !!chrome.runtime.id; } catch (e) { return false; }
  };

  let buf = [];
  let bufMeta = {};
  let bufKey = '';
  let lastTickSec = 0;

  const flush = () => {
    if (!buf.length) return;
    const items = buf;
    const m = bufMeta;
    buf = [];
    try { chrome.runtime.sendMessage({ type: 'flush', items, meta: m }).catch(() => {}); } catch (e) { /* contexte invalidé */ }
  };

  const tick = () => {
    if (!alive()) {
      clearInterval(timer);
      host.remove();
      dropdown.remove();
      return;
    }
    mount();

    const now = Date.now();
    const sec = Math.floor(now / 1000);
    const current = playback();
    const playing = isPlaying(current.video);
    const hidden = document.visibilityState !== 'visible';
    const engaged = !hidden && document.hasFocus() && now - lastActivity < IDLE_MS;
    const live = hidden ? playing && data.settings.countBackground : playing || engaged;

    host.classList.toggle('yts-live', live);

    const gap = lastTickSec ? sec - lastTickSec : 1;
    lastTickSec = sec;

    if (live) {
      const cat = playing ? current.cat : 'b';
      const catchup = hidden && playing ? MAX_CATCHUP_BG : MAX_CATCHUP;
      const n = Math.max(1, Math.min(gap, catchup));
      const m = cat === 'b' ? {} : meta(cat, current.root);
      const key = cat + JSON.stringify(m);
      if (buf.length && key !== bufKey) flush();
      bufKey = key;
      bufMeta = m;
      for (let i = n - 1; i >= 0; i--) buf.push([sec - i, cat, hidden ? 1 : 0]);
    }
    if (buf.length && (buf.length >= FLUSH_EVERY || sec - buf[0][0] >= FLUSH_EVERY + 1)) flush();
  };

  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') flush(); });
  window.addEventListener('pagehide', flush);

  const timer = setInterval(tick, 1000);
  load().then((d) => { data = d; paint(); }).catch(() => {});
  tick();
})();
